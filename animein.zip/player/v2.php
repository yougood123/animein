<?php

// Step 1: Extract the REQUEST_URI parameter
$request_uri = $_SERVER['REQUEST_URI'];

// Step 2: Extract the desired part of the URI
$uri_parts = explode('/', $request_uri);
$theuriiwant = end($uri_parts);

// Step 3: Construct the API URL
$api_url = "https://api.consumet.org/anime/gogoanime/watch/" . $theuriiwant;

try {
    // Step 4: Make an HTTP request and retrieve the JSON response
    $response = file_get_contents($api_url);

    if ($response === false) {
        throw new Exception("Failed to fetch JSON response");
    }

    // Step 5: Decode the JSON response
    $json_data = json_decode($response, true);

    if ($json_data === null) {
        throw new Exception("Failed to decode JSON response");
    }

    // Step 6: Retrieve video sources
    $sources = $json_data['sources'];

    // Step 7: Get the selected quality from the URL parameter (default to the first source)
    $selected_quality = $_GET['quality'] ?? $sources[0]['quality'];

    // Step 8: Find the video URL for the selected quality
    $video_url = null;

    foreach ($sources as $source) {
        if ($source['quality'] === $selected_quality) {
            $video_url = $source['url'];
            break;
        }
    }

    // Step 9: Display the video player using Bootstrap
    echo '<div class="container-fluid">';
    echo '<div class="row justify-content-center">';
    echo '<div class="col-md-8">';
    echo '<div class="embed-responsive embed-responsive-16by9">';
    echo '<video id="player" class="embed-responsive-item" controls>';
    echo '<source src="' . $sources[0]['url'] . '" type="application/x-mpegURL">';
    echo '</video>';
    echo '</div>';
    echo '<div class="text-center mt-3">';
    echo '<div class="btn-group" role="group">';
    foreach ($sources as $source) {
        $quality = $source['quality'];
        $isActive = $quality === $selected_quality ? 'active' : '';
        echo '<button class="btn btn-primary ' . $isActive . '" onclick="changeQuality(\'' . $quality . '\')">' . $quality . '</button>';
    }
    echo '</div>';
    echo '</div>';
    echo '</div>';
    echo '</div>';
    echo '</div>';

    echo '<script src="https://cdn.jsdelivr.net/npm/hls.js@1.4.10/dist/hls.min.js"></script>';
    echo '<script>
        var sources = ' . json_encode($sources) . ';
        var selectedQuality = "' . $selected_quality . '";
        var video = document.getElementById("player");
        var hls;

        function initializePlayer(url) {
            if (Hls.isSupported()) {
                if (hls) {
                    hls.destroy();
                }
                hls = new Hls();
                hls.loadSource(url);
                hls.attachMedia(video);
                hls.on(Hls.Events.MANIFEST_PARSED, function() {
                    video.play();
                });
            } else if (video.canPlayType("application/vnd.apple.mpegurl")) {
                video.src = url;
                video.addEventListener("loadedmetadata", function() {
                    video.play();
                });
            } else {
                console.error("HLS is not supported");
            }
        }

        initializePlayer("' . $video_url . '");

        function changeQuality(quality) {
            var videoUrl = sources.find(function(source) {
                return source.quality === quality;
            }).url;

            initializePlayer(videoUrl);

            selectedQuality = quality;
            updateActiveQualityButton();
        }

        function updateActiveQualityButton() {
            var qualityButtons = document.getElementsByClassName("btn");

            for (var i = 0; i < qualityButtons.length; i++) {
                var button = qualityButtons[i];
                var quality = button.innerHTML;
                if (quality === selectedQuality) {
                    button.classList.add("active");
                } else {
                    button.classList.remove("active");
                }
            }
        }

        updateActiveQualityButton();
    </script>';

    echo '<style>
        .container-fluid {
            padding: 0;
        }
        .embed-responsive {
            position: relative;
            padding-bottom: 56.25%; /* 16:9 aspect ratio */
            height: 0;
            overflow: hidden;
        }
        .embed-responsive .embed-responsive-item,
        .embed-responsive iframe,
        .embed-responsive embed,
        .embed-responsive object,
        .embed-responsive video {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
        }
        .row {
            margin-top: 20px;
        }
        .btn-group .btn {
            border-radius: 0;
        }
        .btn-group .btn.active {
            background-color: #007bff;
        }
    </style>';
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}

?>
