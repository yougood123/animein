<?php
// Step 1: Extract the REQUEST_URI parameter
$request_uri = $_SERVER['REQUEST_URI'];

// Step 2: Extract the desired part of the URI
$uri_parts = explode('/', $request_uri);
$theuriiwant = end($uri_parts);

// Step 3: Construct the API URL
$api_url = "https://api.consumet.org/anime/gogoanime/watch/" . $theuriiwant;

try {
    // Step 4: Make an HTTP request and retrieve the JSON response
    $response = file_get_contents($api_url);

    if ($response === false) {
        throw new Exception("Failed to fetch JSON response");
    }

    // Step 5: Decode the JSON response
    $json_data = json_decode($response, true);

    if ($json_data === null) {
        throw new Exception("Failed to decode JSON response");
    }

    // Step 6: Retrieve video sources
    $sources = $json_data['sources'];

    // Step 7: Get the selected quality from the URL parameter (default to the first source)
    $selected_quality = $_GET['quality'] ?? $sources[2]['quality'];

    // Step 8: Find the video URL for the selected quality
    $video_url = null;

    foreach ($sources as $source) {
        if ($source['quality'] === $selected_quality) {
            $video_url = $source['url'];
            break;
        }
    }

    // Display the video player using Video.js
    echo '<div id="player-container">
        <video
            id="video-player"
            class="video-js vjs-default-skin"
            controls
            preload="auto"
            width="800"
            height="450"
            data-setup=\'{}\'
        >
            <source src="' . $video_url . '" type="application/x-mpegURL">
        </video>
        <div id="quality-changer-container">
            <label for="quality-select"><i class="fas fa-cog"></i></label>
            <select id="quality-select">';

    foreach ($sources as $source) {
        $quality = $source['quality'];
        echo '<option value="' . $quality . '"';
        if ($selected_quality === $quality) {
            echo ' selected';
        }
        echo '>' . $quality . '</option>';
    }

    echo '</select>
    </div>
</div>';

    echo '<style>
    body {
        margin: 0;
        padding: 0;
    }
    #player-container {
        width: 100%;
        height: 100vh;
        position: relative;
    }
    #video-player {
        background-color: #000;
        width: 100%;
        height: 100%;
    }
    .vjs-big-play-button {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        z-index: 1;
    }
    #quality-changer-container {
        position: absolute;
        bottom: 32px;
        right: 10px;
        z-index: 2;
        background-color: rgba(0, 0, 0, 0);
        border-radius: 3px;
        padding: 5px;
        font-family: Arial, sans-serif;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        display: block;
        transition: opacity 0.2s ease;
    }
    #quality-changer-container label {
        margin-right: 5px;
    }
    #quality-select {
        appearance: none;
        background: transparent;
        border: none;
        font-size: 11px;
        color: #fff;
        cursor: pointer;
    }
    #quality-select option {
        background: ;
        border: none;
        color: #333;
    }
</style>';
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
?>

<!-- Add the Video.js and videojs-hls-quality-selector plugin scripts -->
<link href="https://vjs.zencdn.net/8.3.0/video-js.css" rel="stylesheet">
<script src="https://vjs.zencdn.net/8.3.0/video.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/videojs-hls-quality-selector@1.1.4/dist/videojs-hls-quality-selector.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/hls.js@latest"></script>

<!-- Add Font Awesome CSS -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" integrity="sha512-mVlg0PkG1p0wY1GQy7l2T7Tx61qljH9E8fDhJZP7CZ6mu+6bpqoVzK0NDpCVbE+h7OKnBtMLxz4Ysjg5HzLEg==" crossorigin="anonymous" referrerpolicy="no-referrer" />

<!-- Add the inflearn-videojs-skins theme -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/inflearn-videojs-skins@1.0.10/dist/inflearn-videojs-skins.min.css">

<script>
    $(document).ready(function () {
        const player = videojs('video-player', {
            // Add any additional Video.js options here
            width: 800,
            height: 450,
            controlBar: {
                children: [
                    'playToggle',
                    'volumePanel',
                    'currentTimeDisplay',
                    'timeDivider',
                    'durationDisplay',
                    'progressControl',
                    'liveDisplay',
                    'seekToLive',
                    'hlsQualitySelector', // Add the quality selector to the control bar
                    'fullscreenToggle',
                ],
            },
        });

        // If HLS is not natively supported, use hls.js to play the video
        if (!Hls.isSupported()) {
            const hlsPlayer = new Hls();
            hlsPlayer.loadSource('<?php echo $video_url; ?>');
            hlsPlayer.attachMedia(player.media);
        }

        // Quality changer event handler
        $('#quality-select').change(function () {
            const selectedQuality = $(this).val();
            const newVideoUrl = getVideoUrlForQuality(selectedQuality);
            player.src({
                src: newVideoUrl,
                type: 'application/x-mpegURL',
            });
            player.play();
        });

        // Function to get the video URL for a specific quality
        function getVideoUrlForQuality(quality) {
            const sources = <?php echo json_encode($sources); ?>;
            const source = sources.find((item) => item.quality === quality);
            return source ? source.url : null;
        }

        // Add event listener for player controls show/hide
        player.on('userinactive', function () {
            $('#quality-changer-container').fadeOut(200);
        });

        player.on('useractive', function () {
            $('#quality-changer-container').fadeIn(200);
        });
    });
</script>
