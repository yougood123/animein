<?php 
$conn = mysqli_connect("localhost", 'u318298537_anime' , 'Aryan123@', "u318298537_anime") or die("Connection fail");


$websiteTitle = "AnimeIN"; // Website Name
$websiteUrl = "//{$_SERVER['SERVER_NAME']}";  // Website URL
$websiteLogo = $websiteUrl . "/files/images/logo.png?v=2"; // Logo
$contactEmail = "support@animein.fun"; // Contact Email

$version = "0.4";

//Donate 
$donate = "https://www.buymeacoffee.com/dgeeta929U";

// Socials 
$telegram = "https://t.me/#"; // telegram
$discord = "https://discord.gg/the-antinity-community-842960721524424705"; // Discord
$redit = "https://www.reddit.com/r/animein/"; // Reddit
$twitter = "#"; // Twitter
 


$disqus = "https://indianime.disqus.com"; // Disqus


// API URL
$api = "https://ziaapi-ywfb.onrender.com"; // https://github.com/shashankktiwariii/anikatsu-api


$banner = $websiteUrl . "/files/images/logo.png";  //Banner
?>
